let wasm_bindgen = (function(exports) {
    let script_src;
    if (typeof document !== 'undefined' && document.currentScript !== null) {
        script_src = new URL(document.currentScript.src, location.href).toString();
    }

    /**
     * Build an unsigned base64-encoded PSBT for a BTC/LTC send.
     *
     * Input is a single JSON object — see `BuildPsbtParamsJson` for the
     * shape. Output is base64 PSBT string ready to feed into `btc_sign_psbt`.
     *
     * v1 scope: single-recipient P2WPKH (BIP84) sends with optional change
     * output. See `btc-ext/src/build.rs` for scope details. Errors come
     * back as `JsValue` strings.
     * @param {string} params_json
     * @returns {string}
     */
    function btc_build_psbt(params_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(params_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.btc_build_psbt(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.btc_build_psbt = btc_build_psbt;

    /**
     * Derive a BTC or LTC address from a BIP39 mnemonic + BIP32 path.
     *
     * Returns the bech32(m)-encoded address string.
     *
     * Args:
     * - `mnemonic`: BIP39 mnemonic phrase
     * - `passphrase`: BIP39 passphrase (empty string if unused)
     * - `network`: `"btc-mainnet"` | `"btc-testnet"` | `"ltc-mainnet"` | `"ltc-testnet"`
     * - `path`: BIP32 derivation path (e.g. `"m/84'/0'/0'/0/0"`)
     * - `kind`: `"p2wpkh"` (BIP84) | `"p2tr"` (BIP86)
     * @param {string} mnemonic
     * @param {string} passphrase
     * @param {string} network
     * @param {string} path
     * @param {string} kind
     * @returns {string}
     */
    function btc_derive_address(mnemonic, passphrase, network, path, kind) {
        let deferred7_0;
        let deferred7_1;
        try {
            const ptr0 = passStringToWasm0(mnemonic, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(passphrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(network, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ptr4 = passStringToWasm0(kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len4 = WASM_VECTOR_LEN;
            const ret = wasm.btc_derive_address(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4);
            var ptr6 = ret[0];
            var len6 = ret[1];
            if (ret[3]) {
                ptr6 = 0; len6 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred7_0 = ptr6;
            deferred7_1 = len6;
            return getStringFromWasm0(ptr6, len6);
        } finally {
            wasm.__wbindgen_free(deferred7_0, deferred7_1, 1);
        }
    }
    exports.btc_derive_address = btc_derive_address;

    /**
     * Extract the final network-broadcastable transaction hex from a fully-
     * signed PSBT. After `btc_sign_psbt` has populated every input's witness,
     * this finalizes the PSBT and serializes the resulting transaction as
     * raw hex ready for the `/wallet/broadcast` endpoint.
     * @param {string} psbt_base64
     * @returns {string}
     */
    function btc_extract_tx(psbt_base64) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(psbt_base64, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.btc_extract_tx(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.btc_extract_tx = btc_extract_tx;

    /**
     * Sign a base64-encoded PSBT with the **master** xprv derived from the
     * mnemonic. `Psbt::sign` walks each input's `bip32_derivation` and checks
     * the fingerprint against the provided xprv — since `btc_build_psbt`
     * stores the master fingerprint, the master xprv is what we must pass
     * here. Earlier revisions passed an account-level xprv and the
     * fingerprint mismatch silently produced empty `partial_sigs`,
     * triggering "PSBT finalization failed: Missing pubkey for a pkh/wpkh"
     * from miniscript downstream.
     *
     * Inputs whose origin doesn't match this seed's master fingerprint are
     * left untouched — correct for multi-signer flows.
     *
     * The `master_path` parameter is **unused** (kept in the JS signature
     * for backward compatibility with existing v0.3 callers). It can be
     * dropped from the JS facade later; for now the wrapper ignores it.
     *
     * Returns JSON: `{ "psbt": "<base64>", "inputs_total": N, "inputs_signed": M }`.
     * @param {string} mnemonic
     * @param {string} passphrase
     * @param {string} network
     * @param {string} _master_path
     * @param {string} psbt_base64
     * @returns {string}
     */
    function btc_sign_psbt(mnemonic, passphrase, network, _master_path, psbt_base64) {
        let deferred7_0;
        let deferred7_1;
        try {
            const ptr0 = passStringToWasm0(mnemonic, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(passphrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(network, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(_master_path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ptr4 = passStringToWasm0(psbt_base64, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len4 = WASM_VECTOR_LEN;
            const ret = wasm.btc_sign_psbt(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4);
            var ptr6 = ret[0];
            var len6 = ret[1];
            if (ret[3]) {
                ptr6 = 0; len6 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred7_0 = ptr6;
            deferred7_1 = len6;
            return getStringFromWasm0(ptr6, len6);
        } finally {
            wasm.__wbindgen_free(deferred7_0, deferred7_1, 1);
        }
    }
    exports.btc_sign_psbt = btc_sign_psbt;

    /**
     * Compute key image without needing the output public key.
     *
     * This version derives the output key from the view/spend keys and tx_pub_key,
     * useful for verifying spent outputs from LWS which doesn't provide output_key.
     *
     * Returns JSON: { "success": true, "data": "<key_image_hex>" }
     * or: { "success": false, "error": "<message>" }
     * @param {string} view_key
     * @param {string} spend_key
     * @param {string} tx_pub_key
     * @param {number} output_index
     * @returns {string}
     */
    function compute_key_image(view_key, spend_key, tx_pub_key, output_index) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(view_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(spend_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(tx_pub_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.compute_key_image(ptr0, len0, ptr1, len1, ptr2, len2, output_index);
            deferred4_0 = ret[0];
            deferred4_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.compute_key_image = compute_key_image;

    /**
     * Derive a key image from output public key and spend key.
     *
     * This is used to check if an output has been spent. The key image is:
     * `(spend_key + key_offset) * Hp(output_public_key)`
     * where Hp is hash-to-point.
     *
     * # Arguments
     * * `output_public_key_hex` - The output's public key (32 bytes, hex)
     * * `spend_key_hex` - The wallet's private spend key (32 bytes, hex)
     * * `key_offset_hex` - The key offset for this output (32 bytes, hex)
     *
     * # Returns
     * JSON with the key image hex or error.
     * @param {string} output_public_key_hex
     * @param {string} spend_key_hex
     * @param {string} key_offset_hex
     * @returns {string}
     */
    function derive_key_image(output_public_key_hex, spend_key_hex, key_offset_hex) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(output_public_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(spend_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(key_offset_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.derive_key_image(ptr0, len0, ptr1, len1, ptr2, len2);
            deferred4_0 = ret[0];
            deferred4_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.derive_key_image = derive_key_image;

    /**
     * Derive key image for an output (useful for spend detection).
     *
     * # Arguments
     * * `view_key` - Private view key (hex)
     * * `spend_key` - Private spend key (hex)
     * * `tx_pub_key` - Transaction public key (hex)
     * * `output_index` - Output index within transaction
     * * `output_key` - Output public key (hex)
     *
     * # Returns
     * Key image as hex string.
     * @param {string} view_key
     * @param {string} spend_key
     * @param {string} tx_pub_key
     * @param {number} output_index
     * @param {string} output_key
     * @returns {string}
     */
    function derive_output_key_image(view_key, spend_key, tx_pub_key, output_index, output_key) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(view_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(spend_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(tx_pub_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(output_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ret = wasm.derive_output_key_image(ptr0, len0, ptr1, len1, ptr2, len2, output_index, ptr3, len3);
            deferred5_0 = ret[0];
            deferred5_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    exports.derive_output_key_image = derive_output_key_image;

    /**
     * Estimate the fee for a transaction.
     *
     * # Arguments
     * * `num_inputs` - Number of inputs
     * * `num_outputs` - Number of outputs (including change)
     * * `fee_per_byte` - Fee per byte from LWS
     * * `fee_mask` - Fee mask for rounding
     *
     * # Returns
     * Estimated fee in atomic units.
     * @param {number} num_inputs
     * @param {number} num_outputs
     * @param {bigint} fee_per_byte
     * @param {bigint} fee_mask
     * @returns {string}
     */
    function estimate_fee(num_inputs, num_outputs, fee_per_byte, fee_mask) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.estimate_fee(num_inputs, num_outputs, fee_per_byte, fee_mask);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    exports.estimate_fee = estimate_fee;

    /**
     * Complete an adaptor partial with the adaptor secret `t`.
     * Returns the completed partial scalar (32 bytes hex).
     * @param {string} adaptor_partial_s_hex
     * @param {string} adaptor_secret_t_hex
     * @returns {string}
     */
    function grin_adaptor_complete(adaptor_partial_s_hex, adaptor_secret_t_hex) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(adaptor_partial_s_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(adaptor_secret_t_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_adaptor_complete(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_adaptor_complete = grin_adaptor_complete;

    /**
     * Extract the adaptor secret `t` from a completed partial signature given
     * the original adaptor partial. Used by atomic-swap watchers — once a
     * counterparty publishes the completed signature on chain, the watcher
     * recovers `t` and uses it to claim their side of the swap.
     * @param {string} completed_partial_s_hex
     * @param {string} adaptor_partial_s_hex
     * @returns {string}
     */
    function grin_adaptor_extract_secret(completed_partial_s_hex, adaptor_partial_s_hex) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(completed_partial_s_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(adaptor_partial_s_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_adaptor_extract_secret(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_adaptor_extract_secret = grin_adaptor_extract_secret;

    /**
     * Produce an adaptor partial signature.
     * @param {string} secret_key_hex
     * @param {string} secret_nonce_hex
     * @param {string} public_nonce_total_no_t_hex
     * @param {string} public_key_total_hex
     * @param {string} adaptor_point_t_hex
     * @param {string} message_hex
     * @returns {string}
     */
    function grin_adaptor_partial_sign(secret_key_hex, secret_nonce_hex, public_nonce_total_no_t_hex, public_key_total_hex, adaptor_point_t_hex, message_hex) {
        let deferred8_0;
        let deferred8_1;
        try {
            const ptr0 = passStringToWasm0(secret_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(secret_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(public_nonce_total_no_t_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(public_key_total_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ptr4 = passStringToWasm0(adaptor_point_t_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len4 = WASM_VECTOR_LEN;
            const ptr5 = passStringToWasm0(message_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len5 = WASM_VECTOR_LEN;
            const ret = wasm.grin_adaptor_partial_sign(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4, ptr5, len5);
            var ptr7 = ret[0];
            var len7 = ret[1];
            if (ret[3]) {
                ptr7 = 0; len7 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred8_0 = ptr7;
            deferred8_1 = len7;
            return getStringFromWasm0(ptr7, len7);
        } finally {
            wasm.__wbindgen_free(deferred8_0, deferred8_1, 1);
        }
    }
    exports.grin_adaptor_partial_sign = grin_adaptor_partial_sign;

    /**
     * Verify an adaptor partial signature. Returns true if the partial WILL
     * complete to a valid normal partial when combined with the adaptor
     * secret `t` (where T = t·G).
     * @param {string} adaptor_partial_s_hex
     * @param {string} public_nonce_i_hex
     * @param {string} public_key_i_hex
     * @param {string} public_nonce_total_no_t_hex
     * @param {string} public_key_total_hex
     * @param {string} adaptor_point_t_hex
     * @param {string} message_hex
     * @returns {boolean}
     */
    function grin_adaptor_partial_verify(adaptor_partial_s_hex, public_nonce_i_hex, public_key_i_hex, public_nonce_total_no_t_hex, public_key_total_hex, adaptor_point_t_hex, message_hex) {
        const ptr0 = passStringToWasm0(adaptor_partial_s_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(public_nonce_i_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(public_key_i_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(public_nonce_total_no_t_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        const ptr4 = passStringToWasm0(public_key_total_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len4 = WASM_VECTOR_LEN;
        const ptr5 = passStringToWasm0(adaptor_point_t_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len5 = WASM_VECTOR_LEN;
        const ptr6 = passStringToWasm0(message_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len6 = WASM_VECTOR_LEN;
        const ret = wasm.grin_adaptor_partial_verify(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4, ptr5, len5, ptr6, len6);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    exports.grin_adaptor_partial_verify = grin_adaptor_partial_verify;

    /**
     * Compute `(a + b) mod n` over 32-byte scalars.
     * @param {string} a_hex
     * @param {string} b_hex
     * @returns {string}
     */
    function grin_blind_add(a_hex, b_hex) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(a_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(b_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_blind_add(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_blind_add = grin_blind_add;

    /**
     * Compute `(a - b) mod n` over 32-byte scalars.
     * @param {string} a_hex
     * @param {string} b_hex
     * @returns {string}
     */
    function grin_blind_sub(a_hex, b_hex) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(a_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(b_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_blind_sub(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_blind_sub = grin_blind_sub;

    /**
     * Sum N 32-byte scalars modulo the secp256k1 curve order.
     * `scalars_concat_hex` is the concatenation of N 64-hex-char scalars.
     * @param {string} scalars_concat_hex
     * @returns {string}
     */
    function grin_blind_sum(scalars_concat_hex) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(scalars_concat_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_blind_sum(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_blind_sum = grin_blind_sum;

    /**
     * Create a Bulletproof range proof.
     *
     * All `_hex` arguments are 32-byte scalars (64 hex chars). `value` is in
     * nanogrin. `rewind_nonce` will allow the receiver to recover the value.
     * `private_nonce` should be a fresh CSPRNG-derived secret known only to
     * the prover.
     *
     * Returns the proof bytes as hex (typically ~676 bytes / 1352 hex chars
     * for a single 64-bit range).
     * @param {bigint} value
     * @param {string} blinding_factor_hex
     * @param {string} rewind_nonce_hex
     * @param {string} private_nonce_hex
     * @returns {string}
     */
    function grin_bullet_proof_create(value, blinding_factor_hex, rewind_nonce_hex, private_nonce_hex) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(blinding_factor_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(rewind_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(private_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.grin_bullet_proof_create(value, ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    exports.grin_bullet_proof_create = grin_bullet_proof_create;

    /**
     * Rewind a Bulletproof, recovering the committed value (and a derived
     * blinding factor for the recipient to use later).
     *
     * Returns JSON: `{ "value": "...", "blinding_factor_hex": "..." }` on
     * successful rewind, or `null` if the nonce doesn't match the proof.
     * @param {string} commit_hex
     * @param {string} rewind_nonce_hex
     * @param {string} proof_hex
     * @returns {string}
     */
    function grin_bullet_proof_rewind(commit_hex, rewind_nonce_hex, proof_hex) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(commit_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(rewind_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(proof_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.grin_bullet_proof_rewind(ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    exports.grin_bullet_proof_rewind = grin_bullet_proof_rewind;

    /**
     * Verify a Bulletproof against a Pedersen commitment.
     *
     * `commit_hex` is the 33-byte commitment (66 hex chars).
     * `proof_hex` is the variable-length proof bytes (hex).
     * Returns `true` if valid, `false` if invalid.
     * @param {string} commit_hex
     * @param {string} proof_hex
     * @returns {boolean}
     */
    function grin_bullet_proof_verify(commit_hex, proof_hex) {
        const ptr0 = passStringToWasm0(commit_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(proof_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.grin_bullet_proof_verify(ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    exports.grin_bullet_proof_verify = grin_bullet_proof_verify;

    /**
     * @param {string} params_json
     * @returns {string}
     */
    function grin_create_grin_voucher(params_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(params_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_create_grin_voucher(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_create_grin_voucher = grin_create_grin_voucher;

    /**
     * @param {string} params_json
     * @returns {string}
     */
    function grin_create_invoice(params_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(params_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_create_invoice(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_create_invoice = grin_create_invoice;

    /**
     * @param {string} params_json
     * @returns {string}
     */
    function grin_create_send_transaction(params_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(params_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_create_send_transaction(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_create_send_transaction = grin_create_send_transaction;

    /**
     * Derive the 64-byte Grin extended private key from a BIP39 mnemonic.
     *
     * Matches `grin-wallet` and Grim — uses HMAC-SHA512 with key `"IamVoldemort"`
     * over the raw BIP39 entropy (NOT the 64-byte BIP39 PBKDF2 seed).
     *
     * Returns JSON: `{ "extended_private_key_hex": "...", "secret_key_hex": "...", "chain_code_hex": "..." }`.
     * @param {string} mnemonic
     * @returns {string}
     */
    function grin_derive_extended_key(mnemonic) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(mnemonic, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_derive_extended_key(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_derive_extended_key = grin_derive_extended_key;

    /**
     * LEGACY: derive the v1/v2-style ext key (`useBip39=true` —
     * PBKDF2-then-HMAC). Used to compute the fallback ext-key the
     * orchestrators try when the v3 derivation can't reproduce a
     * stored input commitment. Sunset 2026-11-15.
     *
     * Returns hex of the 64-byte ext key (no JSON wrapper — single-purpose).
     * @param {string} mnemonic
     * @returns {string}
     */
    function grin_derive_extended_key_legacy_bip39(mnemonic) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(mnemonic, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_derive_extended_key_legacy_bip39(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_derive_extended_key_legacy_bip39 = grin_derive_extended_key_legacy_bip39;

    /**
     * Derive the full Grin keyset from a mnemonic in one call. Convenience
     * wrapper that bundles the extended key, root secp256k1 pubkey, and the
     * default (index-0) slatepack address.
     *
     * `network` must be `"mainnet"` or `"testnet"`.
     *
     * Returns JSON:
     * ```text
     * {
     *   "extended_private_key_hex": "...",  // 128 hex chars (64 bytes)
     *   "secret_key_hex": "...",            //  64 hex chars (32 bytes)
     *   "chain_code_hex": "...",            //  64 hex chars (32 bytes)
     *   "public_key_hex": "...",            //  66 hex chars (33 bytes, compressed)
     *   "slatepack_address": "grin1..."     // bech32, default address index 0
     * }
     * ```
     * @param {string} mnemonic
     * @param {string} network
     * @returns {string}
     */
    function grin_derive_keys(mnemonic, network) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(mnemonic, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(network, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_derive_keys(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_derive_keys = grin_derive_keys;

    /**
     * grin-ext crate version. Useful for runtime version sanity checks.
     * @returns {string}
     */
    function grin_ext_version() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.grin_ext_version();
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    exports.grin_ext_version = grin_ext_version;

    /**
     * @param {string} params_json
     * @returns {string}
     */
    function grin_finalize_invoice(params_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(params_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_finalize_invoice(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_finalize_invoice = grin_finalize_invoice;

    /**
     * @param {string} params_json
     * @returns {string}
     */
    function grin_finalize_send_slate(params_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(params_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_finalize_send_slate(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_finalize_send_slate = grin_finalize_send_slate;

    /**
     * Recover the BIP32 path of one of the wallet's own on-chain outputs from its
     * commitment + value alone. Enables stateless scan-based spending: the v3
     * `/wallet/grin/scan` returns `{commit, value, ...}` but not the derivation
     * path, while `grin_create_send_transaction` requires each input's path to
     * re-derive its blinding factor.
     *
     * Searches child indices `n` in `0..=max_n` over the standard Smirk layout
     * `[0, 0, n, 0]`, applying the SAME candidate matrix the send builder uses per
     * input (v3/legacy key × Regular/None switch × depth-3/4). Returns the matching
     * 4-level path as a JSON array (e.g. `"[0,0,7,0]"`), or the string `"null"` if
     * no index in range reproduces the commitment (caller must then drop that
     * output — never feed an unidentified input to the send builder).
     *
     * `legacy_ext_key_hex` may be empty to skip the legacy fallback. `value` is in
     * nanogrin.
     * @param {string} ext_key_hex
     * @param {string} legacy_ext_key_hex
     * @param {string} commit_hex
     * @param {bigint} value
     * @param {number} max_n
     * @returns {string}
     */
    function grin_identify_output(ext_key_hex, legacy_ext_key_hex, commit_hex, value, max_n) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(ext_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(legacy_ext_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(commit_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.grin_identify_output(ptr0, len0, ptr1, len1, ptr2, len2, value, max_n);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    exports.grin_identify_output = grin_identify_output;

    /**
     * Serialize kernel features in Grin's v2 protocol wire format.
     *
     * Returns the bytes as hex.
     * @param {string} kind
     * @param {bigint | null} [fee]
     * @param {bigint | null} [lock_height]
     * @param {number | null} [relative_height]
     * @returns {string}
     */
    function grin_kernel_features_bytes(kind, fee, lock_height, relative_height) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_kernel_features_bytes(ptr0, len0, !isLikeNone(fee), isLikeNone(fee) ? BigInt(0) : fee, !isLikeNone(lock_height), isLikeNone(lock_height) ? BigInt(0) : lock_height, isLikeNone(relative_height) ? Number.MAX_SAFE_INTEGER : (relative_height) >>> 0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_kernel_features_bytes = grin_kernel_features_bytes;

    /**
     * Compute the 32-byte BLAKE2b message that should be Schnorr-signed for a
     * kernel of the given type.
     *
     * `kind` selects the variant: `"plain"`, `"coinbase"`, `"height_locked"`,
     * or `"nrd"`. `fee` is required for everything except coinbase.
     * `lock_height` is required for `height_locked` only. `relative_height` is
     * required for `nrd` only and must be in `[1, 10080]` (one week).
     *
     * Returns the message hash as 64 hex chars.
     * @param {string} kind
     * @param {bigint | null} [fee]
     * @param {bigint | null} [lock_height]
     * @param {number | null} [relative_height]
     * @returns {string}
     */
    function grin_kernel_sig_msg(kind, fee, lock_height, relative_height) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_kernel_sig_msg(ptr0, len0, !isLikeNone(fee), isLikeNone(fee) ? BigInt(0) : fee, !isLikeNone(lock_height), isLikeNone(lock_height) ? BigInt(0) : lock_height, isLikeNone(relative_height) ? Number.MAX_SAFE_INTEGER : (relative_height) >>> 0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_kernel_sig_msg = grin_kernel_sig_msg;

    /**
     * Create a Pedersen commitment to `(value, blinding_factor)`.
     *
     * `blinding_factor_hex` is 32 bytes (64 hex chars).
     * Returns 33 bytes (66 hex chars) — the commitment.
     * @param {bigint} value
     * @param {string} blinding_factor_hex
     * @returns {string}
     */
    function grin_pedersen_commit(value, blinding_factor_hex) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(blinding_factor_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_pedersen_commit(value, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_pedersen_commit = grin_pedersen_commit;

    /**
     * Add two compressed secp256k1 public keys via curve point addition.
     * Inputs are 33-byte hex (66 chars), output is 33-byte hex.
     * @param {string} a_hex
     * @param {string} b_hex
     * @returns {string}
     */
    function grin_point_add(a_hex, b_hex) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(a_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(b_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_point_add(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_point_add = grin_point_add;

    /**
     * Sum N compressed pubkeys. `points_concat_hex` is the concatenation of
     * 33-byte (66-hex-char) pubkeys. Returns the sum as 33-byte hex.
     * @param {string} points_concat_hex
     * @returns {string}
     */
    function grin_point_sum(points_concat_hex) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(points_concat_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_point_sum(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_point_sum = grin_point_sum;

    /**
     * Convert a 33-byte compressed secp256k1 public key (0x02/0x03 prefix)
     * to a 33-byte Grin Pedersen commitment (0x08/0x09 prefix). Useful for
     * constructing the kernel excess from `P_total`.
     * @param {string} pubkey_hex
     * @returns {string}
     */
    function grin_pubkey_to_commitment(pubkey_hex) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(pubkey_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_pubkey_to_commitment(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_pubkey_to_commitment = grin_pubkey_to_commitment;

    /**
     * Random fresh 32-byte secp256k1 scalar (for kernel nonces, BP nonces).
     * Returns hex.
     * @returns {string}
     */
    function grin_random_secret_nonce() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.grin_random_secret_nonce();
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    exports.grin_random_secret_nonce = grin_random_secret_nonce;

    /**
     * Receiver finalize for invoice flow (I3): aggregate partials + verify
     * the final kernel signature.
     * @param {string} i2_slate_json
     * @param {string} context_slate_id
     * @param {bigint} context_amount
     * @param {string} context_output_blind_hex
     * @param {string} context_kernel_nonce_hex
     * @param {string} context_commitment_hex
     * @param {string} context_rewind_nonce_hex
     * @returns {string}
     */
    function grin_receiver_finalize_i3(i2_slate_json, context_slate_id, context_amount, context_output_blind_hex, context_kernel_nonce_hex, context_commitment_hex, context_rewind_nonce_hex) {
        let deferred8_0;
        let deferred8_1;
        try {
            const ptr0 = passStringToWasm0(i2_slate_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(context_slate_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(context_output_blind_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(context_kernel_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ptr4 = passStringToWasm0(context_commitment_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len4 = WASM_VECTOR_LEN;
            const ptr5 = passStringToWasm0(context_rewind_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len5 = WASM_VECTOR_LEN;
            const ret = wasm.grin_receiver_finalize_i3(ptr0, len0, ptr1, len1, context_amount, ptr2, len2, ptr3, len3, ptr4, len4, ptr5, len5);
            var ptr7 = ret[0];
            var len7 = ret[1];
            if (ret[3]) {
                ptr7 = 0; len7 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred8_0 = ptr7;
            deferred8_1 = len7;
            return getStringFromWasm0(ptr7, len7);
        } finally {
            wasm.__wbindgen_free(deferred8_0, deferred8_1, 1);
        }
    }
    exports.grin_receiver_finalize_i3 = grin_receiver_finalize_i3;

    /**
     * Receiver-init for an invoice flow: receiver creates the slate first.
     * @param {string} slate_id
     * @param {bigint} amount
     * @param {bigint} fee
     * @param {string} kernel_kind
     * @param {bigint | null | undefined} lock_height
     * @param {number | null | undefined} relative_height
     * @param {string} receiver_output_blind_hex
     * @param {string} receiver_kernel_nonce_hex
     * @param {string} bp_rewind_nonce_hex
     * @param {string} bp_private_nonce_hex
     * @param {string} kernel_offset_hex
     * @returns {string}
     */
    function grin_receiver_init_i1(slate_id, amount, fee, kernel_kind, lock_height, relative_height, receiver_output_blind_hex, receiver_kernel_nonce_hex, bp_rewind_nonce_hex, bp_private_nonce_hex, kernel_offset_hex) {
        let deferred9_0;
        let deferred9_1;
        try {
            const ptr0 = passStringToWasm0(slate_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(kernel_kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(receiver_output_blind_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(receiver_kernel_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ptr4 = passStringToWasm0(bp_rewind_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len4 = WASM_VECTOR_LEN;
            const ptr5 = passStringToWasm0(bp_private_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len5 = WASM_VECTOR_LEN;
            const ptr6 = passStringToWasm0(kernel_offset_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len6 = WASM_VECTOR_LEN;
            const ret = wasm.grin_receiver_init_i1(ptr0, len0, amount, fee, ptr1, len1, !isLikeNone(lock_height), isLikeNone(lock_height) ? BigInt(0) : lock_height, isLikeNone(relative_height) ? Number.MAX_SAFE_INTEGER : (relative_height) >>> 0, ptr2, len2, ptr3, len3, ptr4, len4, ptr5, len5, ptr6, len6);
            var ptr8 = ret[0];
            var len8 = ret[1];
            if (ret[3]) {
                ptr8 = 0; len8 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred9_0 = ptr8;
            deferred9_1 = len8;
            return getStringFromWasm0(ptr8, len8);
        } finally {
            wasm.__wbindgen_free(deferred9_0, deferred9_1, 1);
        }
    }
    exports.grin_receiver_init_i1 = grin_receiver_init_i1;

    /**
     * Receiver round: take an S1 slate JSON, produce an S2 slate JSON.
     *
     * Returns JSON: `{ "slate_json": "...", "context": { ... } }`. The
     * `context` carries private state the receiver may use later (e.g. to
     * rewind the bulletproof on chain to recover the value).
     * @param {string} s1_slate_json
     * @param {string} receiver_output_blind_hex
     * @param {string} receiver_kernel_nonce_hex
     * @param {string} bp_rewind_nonce_hex
     * @param {string} bp_private_nonce_hex
     * @returns {string}
     */
    function grin_receiver_round_s2(s1_slate_json, receiver_output_blind_hex, receiver_kernel_nonce_hex, bp_rewind_nonce_hex, bp_private_nonce_hex) {
        let deferred7_0;
        let deferred7_1;
        try {
            const ptr0 = passStringToWasm0(s1_slate_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(receiver_output_blind_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(receiver_kernel_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(bp_rewind_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ptr4 = passStringToWasm0(bp_private_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len4 = WASM_VECTOR_LEN;
            const ret = wasm.grin_receiver_round_s2(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4);
            var ptr6 = ret[0];
            var len6 = ret[1];
            if (ret[3]) {
                ptr6 = 0; len6 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred7_0 = ptr6;
            deferred7_1 = len6;
            return getStringFromWasm0(ptr6, len6);
        } finally {
            wasm.__wbindgen_free(deferred7_0, deferred7_1, 1);
        }
    }
    exports.grin_receiver_round_s2 = grin_receiver_round_s2;

    /**
     * Seed-only Grin output recovery (view-key scheme). Given the wallet's
     * 64-byte extended private key and an on-chain output (commitment +
     * rangeproof), computes the view-key rewind nonce from the commitment,
     * rewinds the proof, and parses the embedded message to recover the
     * derivation path (v3 and legacy/pre-HF2 formats). Returns JSON
     * `{ "value":"...", "key_id_hex":"...", "n_child":N, "depth":D,
     *    "switch":"Regular|None", "blinding_factor_hex":"..." }` on a hit
     * (the output belongs to this wallet), or `null` otherwise. The ext key
     * never leaves the device. `value` is a decimal string (u64 nanogrin).
     * @param {string} ext_key_hex
     * @param {string} commit_hex
     * @param {string} proof_hex
     * @returns {string}
     */
    function grin_recover_output(ext_key_hex, commit_hex, proof_hex) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(ext_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(commit_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(proof_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.grin_recover_output(ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    exports.grin_recover_output = grin_recover_output;

    /**
     * Compute the wallet's `rewind_hash` (32-byte view credential) from the
     * 64-byte extended private key (hex).
     *
     * `rewind_hash = blake2b-256(data = compressed_public_root_key (33B), key = [])`.
     * This is the ONLY secret handed to `POST /wallet/grin/scan` — it lets the
     * backend's view-only rewind scan recognize this wallet's outputs WITHOUT
     * exposing spend authority. Returns the 32-byte hash as 64 hex chars.
     * @param {string} ext_key_hex
     * @returns {string}
     */
    function grin_rewind_hash(ext_key_hex) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(ext_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_rewind_hash(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_rewind_hash = grin_rewind_hash;

    /**
     * Aggregate N partial scalars into `s_total = s_1 + s_2 + ... + s_n`
     * (mod curve order). `partials_concat_hex` is the concatenation of
     * 32-byte (64-hex-char) scalars. Returns the aggregate as 32-byte hex.
     * @param {string} partials_concat_hex
     * @returns {string}
     */
    function grin_schnorr_aggregate_partials(partials_concat_hex) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(partials_concat_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_schnorr_aggregate_partials(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_schnorr_aggregate_partials = grin_schnorr_aggregate_partials;

    /**
     * Build a final 64-byte aggregate Schnorr signature from `R_total` and the
     * aggregated scalar `s_total`.
     *
     * The result verifies as a single-signer signature against the aggregate
     * public key `P_total` — pass it through the existing `grin_schnorr_verify`
     * with `public_key_hex = P_total`.
     * @param {string} public_nonce_total_hex
     * @param {string} aggregate_s_hex
     * @returns {string}
     */
    function grin_schnorr_final_signature(public_nonce_total_hex, aggregate_s_hex) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(public_nonce_total_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(aggregate_s_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_schnorr_final_signature(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_schnorr_final_signature = grin_schnorr_final_signature;

    /**
     * Produce a partial Schnorr signature for one participant in a multi-party
     * signing ceremony.
     *
     * All `_hex` arguments are hex strings:
     * - `secret_key_hex` / `secret_nonce_hex`: 32-byte scalars (64 hex chars)
     * - `public_nonce_total_hex` / `public_key_total_hex`: 33-byte compressed
     *    pubkeys (66 hex chars), each the SUM of all participants' values
     * - `message_hex`: 32-byte digest
     *
     * Returns the partial scalar `s_i` as 32-byte hex.
     * @param {string} secret_key_hex
     * @param {string} secret_nonce_hex
     * @param {string} public_nonce_total_hex
     * @param {string} public_key_total_hex
     * @param {string} message_hex
     * @returns {string}
     */
    function grin_schnorr_partial_sign(secret_key_hex, secret_nonce_hex, public_nonce_total_hex, public_key_total_hex, message_hex) {
        let deferred7_0;
        let deferred7_1;
        try {
            const ptr0 = passStringToWasm0(secret_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(secret_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(public_nonce_total_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(public_key_total_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ptr4 = passStringToWasm0(message_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len4 = WASM_VECTOR_LEN;
            const ret = wasm.grin_schnorr_partial_sign(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4);
            var ptr6 = ret[0];
            var len6 = ret[1];
            if (ret[3]) {
                ptr6 = 0; len6 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred7_0 = ptr6;
            deferred7_1 = len6;
            return getStringFromWasm0(ptr6, len6);
        } finally {
            wasm.__wbindgen_free(deferred7_0, deferred7_1, 1);
        }
    }
    exports.grin_schnorr_partial_sign = grin_schnorr_partial_sign;

    /**
     * Verify a partial Schnorr signature (one participant's contribution).
     * @param {string} partial_s_hex
     * @param {string} public_nonce_i_hex
     * @param {string} public_key_i_hex
     * @param {string} public_nonce_total_hex
     * @param {string} public_key_total_hex
     * @param {string} message_hex
     * @returns {boolean}
     */
    function grin_schnorr_partial_verify(partial_s_hex, public_nonce_i_hex, public_key_i_hex, public_nonce_total_hex, public_key_total_hex, message_hex) {
        const ptr0 = passStringToWasm0(partial_s_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(public_nonce_i_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(public_key_i_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(public_nonce_total_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        const ptr4 = passStringToWasm0(public_key_total_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len4 = WASM_VECTOR_LEN;
        const ptr5 = passStringToWasm0(message_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len5 = WASM_VECTOR_LEN;
        const ret = wasm.grin_schnorr_partial_verify(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4, ptr5, len5);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    exports.grin_schnorr_partial_verify = grin_schnorr_partial_verify;

    /**
     * Sign a 32-byte message hash with a Grin-style Schnorr signature.
     *
     * `secret_key_hex` and `secret_nonce_hex` are 32-byte scalars (64 hex chars).
     * `message_hex` is the 32-byte message digest (64 hex chars).
     *
     * Returns the 64-byte compact signature as 128 hex chars.
     *
     * **The caller is responsible for ensuring the secret_nonce is fresh**
     * (CSPRNG-derived, never-reused). Reusing a nonce across messages with the
     * same secret key reveals the secret key.
     * @param {string} secret_key_hex
     * @param {string} secret_nonce_hex
     * @param {string} message_hex
     * @returns {string}
     */
    function grin_schnorr_sign(secret_key_hex, secret_nonce_hex, message_hex) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(secret_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(secret_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(message_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.grin_schnorr_sign(ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    exports.grin_schnorr_sign = grin_schnorr_sign;

    /**
     * Verify a Grin-style Schnorr signature.
     *
     * `signature_hex` is 64 bytes (128 hex chars). `message_hex` is the 32-byte
     * message digest. `public_key_hex` is the 33-byte compressed secp256k1
     * public key.
     *
     * Returns `true` if the signature is valid, `false` otherwise. Throws on
     * malformed inputs.
     * @param {string} signature_hex
     * @param {string} message_hex
     * @param {string} public_key_hex
     * @returns {boolean}
     */
    function grin_schnorr_verify(signature_hex, message_hex, public_key_hex) {
        const ptr0 = passStringToWasm0(signature_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(message_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(public_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.grin_schnorr_verify(ptr0, len0, ptr1, len1, ptr2, len2);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    exports.grin_schnorr_verify = grin_schnorr_verify;

    /**
     * Derive the compressed secp256k1 public key (33 bytes) from a 32-byte
     * secret key. Both arguments and return value are hex-encoded strings.
     *
     * Equivalent to `Secp256k1Zkp.publicKeyFromSecretKey(secretKey)` in the
     * MWC WASM stack.
     * @param {string} secret_key_hex
     * @returns {string}
     */
    function grin_secp256k1_public_key(secret_key_hex) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(secret_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_secp256k1_public_key(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_secp256k1_public_key = grin_secp256k1_public_key;

    /**
     * Compute the sender-side blind excess for a Grin transaction.
     * Inputs and sender_outputs are concatenated 32-byte scalars (as hex).
     * @param {string} input_blinds_concat_hex
     * @param {string} sender_output_blinds_concat_hex
     * @param {string} kernel_offset_hex
     * @returns {string}
     */
    function grin_sender_blind_excess(input_blinds_concat_hex, sender_output_blinds_concat_hex, kernel_offset_hex) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(input_blinds_concat_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(sender_output_blinds_concat_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(kernel_offset_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.grin_sender_blind_excess(ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    exports.grin_sender_blind_excess = grin_sender_blind_excess;

    /**
     * Sender finalize: take an S2 slate JSON + the SenderContext fields the
     * sender retained from `sender_init_s1`, produce an S3 slate JSON plus
     * the final aggregated 64-byte Schnorr signature for the kernel.
     *
     * The final signature is verified before this function returns; an error
     * is raised if it doesn't check out (which would indicate a bug in slate
     * construction or tampered receiver data).
     *
     * Returns JSON: `{ "slate_json": "...", "final_signature_hex": "..." }`.
     * @param {string} s2_slate_json
     * @param {string} context_slate_id
     * @param {bigint} context_amount
     * @param {bigint} context_fee
     * @param {string} context_kernel_kind
     * @param {bigint | null | undefined} context_lock_height
     * @param {number | null | undefined} context_relative_height
     * @param {string} context_sender_blind_excess_hex
     * @param {string} context_kernel_offset_hex
     * @param {string} context_kernel_nonce_hex
     * @returns {string}
     */
    function grin_sender_finalize_s3(s2_slate_json, context_slate_id, context_amount, context_fee, context_kernel_kind, context_lock_height, context_relative_height, context_sender_blind_excess_hex, context_kernel_offset_hex, context_kernel_nonce_hex) {
        let deferred8_0;
        let deferred8_1;
        try {
            const ptr0 = passStringToWasm0(s2_slate_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(context_slate_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(context_kernel_kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(context_sender_blind_excess_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ptr4 = passStringToWasm0(context_kernel_offset_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len4 = WASM_VECTOR_LEN;
            const ptr5 = passStringToWasm0(context_kernel_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len5 = WASM_VECTOR_LEN;
            const ret = wasm.grin_sender_finalize_s3(ptr0, len0, ptr1, len1, context_amount, context_fee, ptr2, len2, !isLikeNone(context_lock_height), isLikeNone(context_lock_height) ? BigInt(0) : context_lock_height, isLikeNone(context_relative_height) ? Number.MAX_SAFE_INTEGER : (context_relative_height) >>> 0, ptr3, len3, ptr4, len4, ptr5, len5);
            var ptr7 = ret[0];
            var len7 = ret[1];
            if (ret[3]) {
                ptr7 = 0; len7 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred8_0 = ptr7;
            deferred8_1 = len7;
            return getStringFromWasm0(ptr7, len7);
        } finally {
            wasm.__wbindgen_free(deferred8_0, deferred8_1, 1);
        }
    }
    exports.grin_sender_finalize_s3 = grin_sender_finalize_s3;

    /**
     * Build the sender's S1 slate.
     *
     * Returns JSON: `{ "slate_json": "...", "context": { ... } }` where
     * `slate_json` is a serialized v4 slate ready to send to the receiver,
     * and `context` is the private state the sender must retain to finalize.
     *
     * `kernel_kind` is one of `"plain"`, `"coinbase"`, `"height_locked"`, `"nrd"`.
     * `lock_height` and `relative_height` are required for the corresponding
     * kernel kinds. `slate_id` is the caller-supplied slate UUID — pass a
     * fresh v4 UUID string (e.g. `crypto.randomUUID()` in the browser).
     * @param {string} slate_id
     * @param {bigint} amount
     * @param {bigint} fee
     * @param {string} kernel_kind
     * @param {bigint | null | undefined} lock_height
     * @param {number | null | undefined} relative_height
     * @param {string} sender_blind_excess_hex
     * @param {string} kernel_offset_hex
     * @param {string} kernel_nonce_hex
     * @returns {string}
     */
    function grin_sender_init_s1(slate_id, amount, fee, kernel_kind, lock_height, relative_height, sender_blind_excess_hex, kernel_offset_hex, kernel_nonce_hex) {
        let deferred7_0;
        let deferred7_1;
        try {
            const ptr0 = passStringToWasm0(slate_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(kernel_kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(sender_blind_excess_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(kernel_offset_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ptr4 = passStringToWasm0(kernel_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len4 = WASM_VECTOR_LEN;
            const ret = wasm.grin_sender_init_s1(ptr0, len0, amount, fee, ptr1, len1, !isLikeNone(lock_height), isLikeNone(lock_height) ? BigInt(0) : lock_height, isLikeNone(relative_height) ? Number.MAX_SAFE_INTEGER : (relative_height) >>> 0, ptr2, len2, ptr3, len3, ptr4, len4);
            var ptr6 = ret[0];
            var len6 = ret[1];
            if (ret[3]) {
                ptr6 = 0; len6 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred7_0 = ptr6;
            deferred7_1 = len6;
            return getStringFromWasm0(ptr6, len6);
        } finally {
            wasm.__wbindgen_free(deferred7_0, deferred7_1, 1);
        }
    }
    exports.grin_sender_init_s1 = grin_sender_init_s1;

    /**
     * Sender's response to an invoice (I2): adds inputs/change context + their
     * partial signature.
     * @param {string} i1_slate_json
     * @param {string} sender_blind_excess_hex
     * @param {string} sender_kernel_nonce_hex
     * @returns {string}
     */
    function grin_sender_round_i2(i1_slate_json, sender_blind_excess_hex, sender_kernel_nonce_hex) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(i1_slate_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(sender_blind_excess_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(sender_kernel_nonce_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.grin_sender_round_i2(ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    exports.grin_sender_round_i2 = grin_sender_round_i2;

    /**
     * @param {string} params_json
     * @returns {string}
     */
    function grin_sign_incoming_send_slate(params_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(params_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_sign_incoming_send_slate(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_sign_incoming_send_slate = grin_sign_incoming_send_slate;

    /**
     * @param {string} params_json
     * @returns {string}
     */
    function grin_sign_invoice(params_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(params_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_sign_invoice(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_sign_invoice = grin_sign_invoice;

    /**
     * Sign a Grin payment proof. Returns the 64-byte ed25519 signature.
     *
     * `kernel_commitment_hex` is the 33-byte kernel excess commitment from
     * the finalized transaction. `sender_address_hex` is the sender's
     * slatepack-address 32-byte ed25519 pubkey (decoded from bech32).
     * `receiver_secret_hex` is the receiver's ed25519 secret seed.
     * @param {bigint} amount
     * @param {string} kernel_commitment_hex
     * @param {string} sender_address_hex
     * @param {string} receiver_secret_hex
     * @returns {string}
     */
    function grin_sign_payment_proof(amount, kernel_commitment_hex, sender_address_hex, receiver_secret_hex) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(kernel_commitment_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(sender_address_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(receiver_secret_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.grin_sign_payment_proof(amount, ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    exports.grin_sign_payment_proof = grin_sign_payment_proof;

    /**
     * Parse a Grin slate v4 JSON string and re-serialize it.
     *
     * Useful as a slate validator: any slate that round-trips successfully is
     * a structurally valid v4 slate. Returns the canonicalized JSON
     * (whitespace-stripped, default-fields-omitted).
     *
     * Throws on malformed input.
     * @param {string} slate_json
     * @returns {string}
     */
    function grin_slate_round_trip(slate_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(slate_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slate_round_trip(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_slate_round_trip = grin_slate_round_trip;

    /**
     * Extract a small summary from a slate v4 JSON for UI display.
     *
     * Returns JSON: `{ "id": "...", "state": "S1", "amount": "0", "fee": "0",
     * "num_participants": 2, "num_signed": 0 }`.
     * @param {string} slate_json
     * @returns {string}
     */
    function grin_slate_summary(slate_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(slate_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slate_summary(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_slate_summary = grin_slate_summary;

    /**
     * Convert a finalized S3 slate + the sender's inputs/change + the
     * aggregated kernel signature into broadcastable Grin transaction bytes.
     *
     * Inputs are encoded as concatenated `(features_byte || 33-byte commit)`
     * pairs in `inputs_concat_hex` — i.e. each input is 34 hex bytes long
     * (68 hex chars).
     *
     * Outputs are encoded as a JSON array string: `[{"f": 0, "c": "...",
     * "p": "..."}]` where each entry has features byte, 33-byte commitment
     * hex, and rangeproof hex.
     *
     * Returns the full TX as hex (typically 1+ KB).
     * @param {string} s3_slate_json
     * @param {string} sender_inputs_concat_hex
     * @param {string} sender_change_outputs_json
     * @param {string} aggregated_kernel_signature_hex
     * @returns {string}
     */
    function grin_slate_to_transaction_bytes(s3_slate_json, sender_inputs_concat_hex, sender_change_outputs_json, aggregated_kernel_signature_hex) {
        let deferred6_0;
        let deferred6_1;
        try {
            const ptr0 = passStringToWasm0(s3_slate_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(sender_inputs_concat_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(sender_change_outputs_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(aggregated_kernel_signature_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slate_to_transaction_bytes(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
            var ptr5 = ret[0];
            var len5 = ret[1];
            if (ret[3]) {
                ptr5 = 0; len5 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred6_0 = ptr5;
            deferred6_1 = len5;
            return getStringFromWasm0(ptr5, len5);
        } finally {
            wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
        }
    }
    exports.grin_slate_to_transaction_bytes = grin_slate_to_transaction_bytes;

    /**
     * Inverse of `grin_slate_v4_to_bin_hex`. Input: hex-encoded binary bytes.
     * Output: slate v4 JSON string.
     * @param {string} bin_hex
     * @returns {string}
     */
    function grin_slate_v4_from_bin_hex(bin_hex) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(bin_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slate_v4_from_bin_hex(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_slate_v4_from_bin_hex = grin_slate_v4_from_bin_hex;

    /**
     * Serialize a slate JSON to its compact binary form (slatepack payload).
     * Input: slate v4 JSON string. Output: hex-encoded binary bytes.
     * @param {string} slate_json
     * @returns {string}
     */
    function grin_slate_v4_to_bin_hex(slate_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(slate_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slate_v4_to_bin_hex(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_slate_v4_to_bin_hex = grin_slate_v4_to_bin_hex;

    /**
     * Derive a slatepack address (Grim/grin-wallet compatible) from a mnemonic.
     *
     * `network` must be `"mainnet"` or `"testnet"`.
     * `index` is the address index — 0 is the wallet's default address.
     *
     * Returns the bech32-encoded address string (e.g. `"grin1abc..."`).
     * @param {string} mnemonic
     * @param {number} index
     * @param {string} network
     * @returns {string}
     */
    function grin_slatepack_address(mnemonic, index, network) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(mnemonic, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(network, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_address(ptr0, len0, index, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_slatepack_address = grin_slatepack_address;

    /**
     * Derive the receiver's slatepack-address ed25519 secret seed from a
     * mnemonic. Used for signing payment proofs (and any other protocol
     * where the receiver's address-key signs).
     *
     * The derived 32-byte secret is the long-lived ed25519 seed that pairs
     * with `grin_slatepack_address(mnemonic, index, ...)`.
     * @param {string} mnemonic
     * @param {number} index
     * @returns {string}
     */
    function grin_slatepack_address_secret(mnemonic, index) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(mnemonic, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_address_secret(ptr0, len0, index);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_slatepack_address_secret = grin_slatepack_address_secret;

    /**
     * Decode a bech32 slatepack address back to its 32-byte ed25519 public
     * key. Inverse of `grin_slatepack_address`. Returns the hex-encoded
     * pubkey — the form `grin_slatepack_pack_encrypted` /
     * `grin_slatepack_encrypt` expects for the recipient.
     *
     * Accepts both mainnet (`grin1…`) and testnet (`tgrin1…`) HRPs.
     * @param {string} addr
     * @returns {string}
     */
    function grin_slatepack_address_to_pubkey_hex(addr) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(addr, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_address_to_pubkey_hex(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_slatepack_address_to_pubkey_hex = grin_slatepack_address_to_pubkey_hex;

    /**
     * Wrap opaque bytes in slatepack ASCII armor.
     *
     * `payload_hex` is the hex-encoded inner payload (typically the binary
     * SlatepackBin serialization, but treated as opaque here). Returns the
     * human-shareable string `BEGINSLATEPACK. <base58> . ENDSLATEPACK.\n`.
     * @param {string} payload_hex
     * @returns {string}
     */
    function grin_slatepack_armor(payload_hex) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(payload_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_armor(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_slatepack_armor = grin_slatepack_armor;

    /**
     * Parse a SlatepackBin binary (the structure that lives inside slatepack
     * armor) and return its components as JSON.
     *
     * Returns JSON: `{ "version": "1.0", "mode": "plain" | "encrypted",
     * "sender": "grin1..." | null, "payload_hex": "..." }`.
     * @param {string} bin_hex
     * @returns {string}
     */
    function grin_slatepack_bin_decode(bin_hex) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(bin_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_bin_decode(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_slatepack_bin_decode = grin_slatepack_bin_decode;

    /**
     * Wrap an inner payload in a plaintext-mode SlatepackBin (binary structure
     * inside the armor) and return the binary serialization.
     *
     * `inner_payload_hex` is the slate or other inner bytes (typically a
     * binary-serialized SlateV4). `sender` is an optional bech32 slatepack
     * address (e.g. `grin1abc...`). Pass `null` / empty string for none.
     *
     * Returns the SlatepackBin binary as hex.
     * @param {string} inner_payload_hex
     * @param {string | null} [sender]
     * @returns {string}
     */
    function grin_slatepack_bin_encode_plain(inner_payload_hex, sender) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(inner_payload_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            var ptr1 = isLikeNone(sender) ? 0 : passStringToWasm0(sender, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_bin_encode_plain(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_slatepack_bin_encode_plain = grin_slatepack_bin_encode_plain;

    /**
     * Unwrap slatepack ASCII armor.
     *
     * Tolerates surrounding whitespace, messenger quote prefixes (`>`), and
     * arbitrary line breaks. Verifies the embedded SHA256-double-hash
     * checksum. Returns the inner payload as hex.
     *
     * Throws on malformed input (missing header/footer, base58 decode failure,
     * or checksum mismatch).
     * @param {string} armored
     * @returns {string}
     */
    function grin_slatepack_dearmor(armored) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(armored, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_dearmor(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_slatepack_dearmor = grin_slatepack_dearmor;

    /**
     * Decrypt an age-encrypted slatepack payload using the recipient's
     * ed25519 secret key (32-byte hex).
     *
     * Returns the inner cleartext payload as hex.
     * @param {string} encrypted_payload_hex
     * @param {string} secret_key_hex
     * @returns {string}
     */
    function grin_slatepack_decrypt(encrypted_payload_hex, secret_key_hex) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(encrypted_payload_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(secret_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_decrypt(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_slatepack_decrypt = grin_slatepack_decrypt;

    /**
     * Encrypt a payload to a recipient slatepack address.
     *
     * `recipient_pubkey_hex` is the 32-byte ed25519 public key from inside the
     * recipient's bech32 slatepack address (use [`super::keys::grin_slatepack_address`]
     * in reverse — TODO: bech32-decode helper) or the raw 32-byte hex. Returns
     * the encrypted bytes that go into `SlatepackBin.payload` when mode = 1.
     * @param {string} payload_hex
     * @param {string} recipient_pubkey_hex
     * @returns {string}
     */
    function grin_slatepack_encrypt(payload_hex, recipient_pubkey_hex) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(payload_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(recipient_pubkey_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_encrypt(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_slatepack_encrypt = grin_slatepack_encrypt;

    /**
     * One-call helper: encrypt a payload to a recipient, wrap in a
     * SlatepackBin (mode=1), and ASCII-armor the result.
     *
     * Returns the human-shareable `BEGINSLATEPACK...ENDSLATEPACK` string.
     * @param {string} inner_payload_hex
     * @param {string | null | undefined} sender
     * @param {string} recipient_pubkey_hex
     * @returns {string}
     */
    function grin_slatepack_pack_encrypted(inner_payload_hex, sender, recipient_pubkey_hex) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(inner_payload_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            var ptr1 = isLikeNone(sender) ? 0 : passStringToWasm0(sender, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(recipient_pubkey_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_pack_encrypted(ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    exports.grin_slatepack_pack_encrypted = grin_slatepack_pack_encrypted;

    /**
     * One-call helper: take an inner payload (e.g. a binary slate), wrap it in
     * a plaintext SlatepackBin, and ASCII-armor the result.
     *
     * Returns the human-shareable `BEGINSLATEPACK...ENDSLATEPACK` string.
     * @param {string} inner_payload_hex
     * @param {string | null} [sender]
     * @returns {string}
     */
    function grin_slatepack_pack_plain(inner_payload_hex, sender) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(inner_payload_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            var ptr1 = isLikeNone(sender) ? 0 : passStringToWasm0(sender, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_pack_plain(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_slatepack_pack_plain = grin_slatepack_pack_plain;

    /**
     * One-call helper: take an armored slatepack string and return JSON with
     * the parsed inner SlatepackBin fields. Same shape as
     * `grin_slatepack_bin_decode`.
     * @param {string} armored
     * @returns {string}
     */
    function grin_slatepack_unpack(armored) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(armored, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_unpack(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_slatepack_unpack = grin_slatepack_unpack;

    /**
     * One-call helper: dearmor + parse a SlatepackBin + decrypt the payload
     * using the receiver's ed25519 secret. Works for both plaintext and
     * encrypted slatepacks (returns the inner payload hex either way).
     *
     * Returns JSON: `{ "version": "1.0", "mode": "plain" | "encrypted",
     * "sender": "grin1..." | null, "payload_hex": "..." }`.
     * @param {string} armored
     * @param {string} secret_key_hex
     * @returns {string}
     */
    function grin_slatepack_unpack_with_secret(armored, secret_key_hex) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(armored, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(secret_key_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.grin_slatepack_unpack_with_secret(ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    exports.grin_slatepack_unpack_with_secret = grin_slatepack_unpack_with_secret;

    /**
     * @param {string} params_json
     * @returns {string}
     */
    function grin_sweep_grin_voucher(params_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(params_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.grin_sweep_grin_voucher(ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    exports.grin_sweep_grin_voucher = grin_sweep_grin_voucher;

    /**
     * Verify a Grin payment proof. Returns true if the receiver's ed25519
     * signature attests to the given (amount, kernel commitment, sender
     * address) tuple.
     * @param {bigint} amount
     * @param {string} kernel_commitment_hex
     * @param {string} sender_address_hex
     * @param {string} receiver_address_hex
     * @param {string} signature_hex
     * @returns {boolean}
     */
    function grin_verify_payment_proof(amount, kernel_commitment_hex, sender_address_hex, receiver_address_hex, signature_hex) {
        const ptr0 = passStringToWasm0(kernel_commitment_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(sender_address_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(receiver_address_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(signature_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        const ret = wasm.grin_verify_payment_proof(amount, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    exports.grin_verify_payment_proof = grin_verify_payment_proof;

    /**
     * Parse a transaction from hex and return info about it.
     *
     * # Arguments
     * * `hex_data` - The transaction as hex-encoded bytes
     *
     * # Returns
     * JSON with transaction info (inputs, outputs, version) or error.
     * @param {string} hex_data
     * @returns {string}
     */
    function parse_tx(hex_data) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ptr0 = passStringToWasm0(hex_data, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.parse_tx(ptr0, len0);
            deferred2_0 = ret[0];
            deferred2_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    exports.parse_tx = parse_tx;

    /**
     * Build and sign a transaction.
     *
     * This takes LWS-format data and produces a signed transaction ready for broadcast.
     *
     * # Arguments
     * * `params_json` - JSON string containing `TxParams`
     *
     * # Returns
     * JSON with `SignedTx` or error.
     * @param {string} params_json
     * @returns {string}
     */
    function sign_transaction(params_json) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ptr0 = passStringToWasm0(params_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.sign_transaction(ptr0, len0);
            deferred2_0 = ret[0];
            deferred2_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    exports.sign_transaction = sign_transaction;

    /**
     * Simple test function to verify WASM is loaded.
     * @returns {string}
     */
    function test() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.test();
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    exports.test = test;

    /**
     * Validate a Monero or Wownero address and return its components.
     *
     * Automatically detects the address type based on prefix.
     *
     * Returns JSON with address info or error.
     * @param {string} address
     * @returns {string}
     */
    function validate_address(address) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ptr0 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.validate_address(ptr0, len0);
            deferred2_0 = ret[0];
            deferred2_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    exports.validate_address = validate_address;

    /**
     * Get the library version.
     * @returns {string}
     */
    function version() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.version();
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    exports.version = version;
    function __wbg_get_imports() {
        const import0 = {
            __proto__: null,
            __wbg___wbindgen_is_function_5cd60d5cf78b4eef: function(arg0) {
                const ret = typeof(arg0) === 'function';
                return ret;
            },
            __wbg___wbindgen_is_object_b4593df85baada48: function(arg0) {
                const val = arg0;
                const ret = typeof(val) === 'object' && val !== null;
                return ret;
            },
            __wbg___wbindgen_is_string_dde0fd9020db4434: function(arg0) {
                const ret = typeof(arg0) === 'string';
                return ret;
            },
            __wbg___wbindgen_is_undefined_35bb9f4c7fd651d5: function(arg0) {
                const ret = arg0 === undefined;
                return ret;
            },
            __wbg___wbindgen_throw_9c31b086c2b26051: function(arg0, arg1) {
                throw new Error(getStringFromWasm0(arg0, arg1));
            },
            __wbg_call_dfde26266607c996: function() { return handleError(function (arg0, arg1, arg2) {
                const ret = arg0.call(arg1, arg2);
                return ret;
            }, arguments); },
            __wbg_crypto_38df2bab126b63dc: function(arg0) {
                const ret = arg0.crypto;
                return ret;
            },
            __wbg_getRandomValues_c44a50d8cfdaebeb: function() { return handleError(function (arg0, arg1) {
                arg0.getRandomValues(arg1);
            }, arguments); },
            __wbg_getRandomValues_ef12552bf5acd2fe: function() { return handleError(function (arg0, arg1) {
                globalThis.crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
            }, arguments); },
            __wbg_length_56fcd3e2b7e0299d: function(arg0) {
                const ret = arg0.length;
                return ret;
            },
            __wbg_msCrypto_bd5a034af96bcba6: function(arg0) {
                const ret = arg0.msCrypto;
                return ret;
            },
            __wbg_new_with_length_99887c91eae4abab: function(arg0) {
                const ret = new Uint8Array(arg0 >>> 0);
                return ret;
            },
            __wbg_node_84ea875411254db1: function(arg0) {
                const ret = arg0.node;
                return ret;
            },
            __wbg_process_44c7a14e11e9f69e: function(arg0) {
                const ret = arg0.process;
                return ret;
            },
            __wbg_prototypesetcall_5f9bdc8d75e07276: function(arg0, arg1, arg2) {
                Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
            },
            __wbg_randomFillSync_6c25eac9869eb53c: function() { return handleError(function (arg0, arg1) {
                arg0.randomFillSync(arg1);
            }, arguments); },
            __wbg_require_b4edbdcf3e2a1ef0: function() { return handleError(function () {
                const ret = module.require;
                return ret;
            }, arguments); },
            __wbg_static_accessor_GLOBAL_THIS_02344c9b09eb08a9: function() {
                const ret = typeof globalThis === 'undefined' ? null : globalThis;
                return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
            },
            __wbg_static_accessor_GLOBAL_ac6d4ac874d5cd54: function() {
                const ret = typeof global === 'undefined' ? null : global;
                return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
            },
            __wbg_static_accessor_SELF_9b2406c23aeb2023: function() {
                const ret = typeof self === 'undefined' ? null : self;
                return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
            },
            __wbg_static_accessor_WINDOW_b34d2126934e16ba: function() {
                const ret = typeof window === 'undefined' ? null : window;
                return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
            },
            __wbg_subarray_7c6a0da8f3b4a1ba: function(arg0, arg1, arg2) {
                const ret = arg0.subarray(arg1 >>> 0, arg2 >>> 0);
                return ret;
            },
            __wbg_versions_276b2795b1c6a219: function(arg0) {
                const ret = arg0.versions;
                return ret;
            },
            __wbindgen_cast_0000000000000001: function(arg0, arg1) {
                // Cast intrinsic for `Ref(Slice(U8)) -> NamedExternref("Uint8Array")`.
                const ret = getArrayU8FromWasm0(arg0, arg1);
                return ret;
            },
            __wbindgen_cast_0000000000000002: function(arg0, arg1) {
                // Cast intrinsic for `Ref(String) -> Externref`.
                const ret = getStringFromWasm0(arg0, arg1);
                return ret;
            },
            __wbindgen_init_externref_table: function() {
                const table = wasm.__wbindgen_externrefs;
                const offset = table.grow(4);
                table.set(0, undefined);
                table.set(offset + 0, undefined);
                table.set(offset + 1, null);
                table.set(offset + 2, true);
                table.set(offset + 3, false);
            },
        };
        return {
            __proto__: null,
            "./smirk_wasm_bg.js": import0,
        };
    }

    function addToExternrefTable0(obj) {
        const idx = wasm.__externref_table_alloc();
        wasm.__wbindgen_externrefs.set(idx, obj);
        return idx;
    }

    function getArrayU8FromWasm0(ptr, len) {
        ptr = ptr >>> 0;
        return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
    }

    function getStringFromWasm0(ptr, len) {
        return decodeText(ptr >>> 0, len);
    }

    let cachedUint8ArrayMemory0 = null;
    function getUint8ArrayMemory0() {
        if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
            cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
        }
        return cachedUint8ArrayMemory0;
    }

    function handleError(f, args) {
        try {
            return f.apply(this, args);
        } catch (e) {
            const idx = addToExternrefTable0(e);
            wasm.__wbindgen_exn_store(idx);
        }
    }

    function isLikeNone(x) {
        return x === undefined || x === null;
    }

    function passStringToWasm0(arg, malloc, realloc) {
        if (realloc === undefined) {
            const buf = cachedTextEncoder.encode(arg);
            const ptr = malloc(buf.length, 1) >>> 0;
            getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
            WASM_VECTOR_LEN = buf.length;
            return ptr;
        }

        let len = arg.length;
        let ptr = malloc(len, 1) >>> 0;

        const mem = getUint8ArrayMemory0();

        let offset = 0;

        for (; offset < len; offset++) {
            const code = arg.charCodeAt(offset);
            if (code > 0x7F) break;
            mem[ptr + offset] = code;
        }
        if (offset !== len) {
            if (offset !== 0) {
                arg = arg.slice(offset);
            }
            ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
            const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
            const ret = cachedTextEncoder.encodeInto(arg, view);

            offset += ret.written;
            ptr = realloc(ptr, len, offset, 1) >>> 0;
        }

        WASM_VECTOR_LEN = offset;
        return ptr;
    }

    function takeFromExternrefTable0(idx) {
        const value = wasm.__wbindgen_externrefs.get(idx);
        wasm.__externref_table_dealloc(idx);
        return value;
    }

    let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
    cachedTextDecoder.decode();
    function decodeText(ptr, len) {
        return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
    }

    const cachedTextEncoder = new TextEncoder();

    if (!('encodeInto' in cachedTextEncoder)) {
        cachedTextEncoder.encodeInto = function (arg, view) {
            const buf = cachedTextEncoder.encode(arg);
            view.set(buf);
            return {
                read: arg.length,
                written: buf.length
            };
        };
    }

    let WASM_VECTOR_LEN = 0;

    let wasmModule, wasmInstance, wasm;
    function __wbg_finalize_init(instance, module) {
        wasmInstance = instance;
        wasm = instance.exports;
        wasmModule = module;
        cachedUint8ArrayMemory0 = null;
        wasm.__wbindgen_start();
        return wasm;
    }

    async function __wbg_load(module, imports) {
        if (typeof Response === 'function' && module instanceof Response) {
            if (typeof WebAssembly.instantiateStreaming === 'function') {
                try {
                    return await WebAssembly.instantiateStreaming(module, imports);
                } catch (e) {
                    const validResponse = module.ok && expectedResponseType(module.type);

                    if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                        console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                    } else { throw e; }
                }
            }

            const bytes = await module.arrayBuffer();
            return await WebAssembly.instantiate(bytes, imports);
        } else {
            const instance = await WebAssembly.instantiate(module, imports);

            if (instance instanceof WebAssembly.Instance) {
                return { instance, module };
            } else {
                return instance;
            }
        }

        function expectedResponseType(type) {
            switch (type) {
                case 'basic': case 'cors': case 'default': return true;
            }
            return false;
        }
    }

    function initSync(module) {
        if (wasm !== undefined) return wasm;


        if (module !== undefined) {
            if (Object.getPrototypeOf(module) === Object.prototype) {
                ({module} = module)
            } else {
                console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
            }
        }

        const imports = __wbg_get_imports();
        if (!(module instanceof WebAssembly.Module)) {
            module = new WebAssembly.Module(module);
        }
        const instance = new WebAssembly.Instance(module, imports);
        return __wbg_finalize_init(instance, module);
    }

    async function __wbg_init(module_or_path) {
        if (wasm !== undefined) return wasm;


        if (module_or_path !== undefined) {
            if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
                ({module_or_path} = module_or_path)
            } else {
                console.warn('using deprecated parameters for the initialization function; pass a single object instead')
            }
        }

        if (module_or_path === undefined && script_src !== undefined) {
            module_or_path = script_src.replace(/\.js$/, "_bg.wasm");
        }
        const imports = __wbg_get_imports();

        if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
            module_or_path = fetch(module_or_path);
        }

        const { instance, module } = await __wbg_load(await module_or_path, imports);

        return __wbg_finalize_init(instance, module);
    }

    return Object.assign(__wbg_init, { initSync }, exports);
})({ __proto__: null });

export { wasm_bindgen };
