# Smirk Monorepo

Open-source client code for the Smirk multi-currency wallet — Rust crates for chain-specific cryptography, a wasm-bindgen wrapper, and (eventually) the TypeScript packages that power the browser extension and mobile app.

## Status

| Component | Status |
|---|---|
| `crates/monero-oxide/` | Working — Monero + Wownero transaction construction, in production via the smirk-extension v0.2.x stack |
| `crates/secp256k1zkp/` | Vendored — Grin's `grin_secp256k1zkp` v0.7.15 + Smirk patches for wasm32. Provides Bulletproofs, Pedersen commitments, aggsig |
| `crates/smirk-wasm/` | Working — single WASM bundle exposing Monero/Wownero/Grin crypto to JS |
| `crates/grin-ext/` | Working — seed derivation, slatepack address (Grim-verified), Schnorr (single + multi-party + adaptor), slate v4 (JSON + compact binary), Pedersen + Bulletproofs, slatepack codec (armor + bin + age encryption), kernels (incl. NRD), full slate construction (standard + invoice flow), transaction wire-format assembly, payment proofs, 6 high-level wallet orchestrators, cross-validated against `grin_wallet_libwallet` 5.4.0 |
| `crates/btc-ext/` | Working — BIP32/BIP39 derivation, P2WPKH (BIP84) + P2TR (BIP86) addresses for BTC + LTC, PSBT construction + signing + extraction. Built on rust-bitcoin |
| `crates/swap-core/` | Stub — atomic swap state machine, implementation pending (v0.4 work) |
| `packages/wasm/` | Working — `@smirk/wasm` TS bindings around the WASM crypto bundle (BTC PSBT, XMR/WOW signing, full Grin surface incl. wallet orchestrators) |
| `packages/core/` | Working — shared TS lib (API client, crypto, BIP-137 signing, address codecs, HD derivation, session-state + wizard scaffold, pendingOutgoing reconciliation, wallet-flow composition) |
| `packages/assets/` | Working — `@smirk/assets` registry: pure-data definitions (decimals, family, capabilities, networks) for every chain Smirk supports. 44 unit tests. |
| `packages/ui/` | Working — `@smirk/ui` shared Preact components: Home (UnifiedBalance, BalanceCard, ActionRow), SendWizard (5 assets incl. Grin interactive Exchange step), GrinRequestWizard, ReceiveScreen, OnboardingWizard, LockScreen, AppShell + BottomNav, ApprovalScreen (dapp prompt UI), theme registry (7 themes incl. retro themes) |
| `packages/dapp-api/` | Working — `@smirk/dapp-api` transport-agnostic dapp injection: wire protocol, `WalletHandler` dispatcher, page-context `window.smirk` factory, `WalletProvider` / `OriginPermissionStore` / `ApprovalHandler` interfaces. Platform adapters live in `packages/extension/` (and eventually mobile / desktop). |
| `packages/extension/` | Working — Chrome MV3 + Firefox MV3. Keystore + wallet-flow + lockscreen, send (BTC/LTC/XMR/WOW/Grin), receive, social tipping (two-phase create), per-asset detail screen, tri-state balance (confirmed/pending/locked), pendingOutgoing reconciliation. `window.smirk` dapp injection (connect, signMessage for BTC+LTC, isConnected, disconnect, getPublicKeys, getAddresses) with per-origin permissions + standalone approval-window flow + global privacy toggle in Settings. |
| `packages/mobile/` `packages/desktop/` | Not yet populated — Capacitor planned v0.4, Tauri v0.5+ |

The legacy browser extension at [Such-Software/smirk-extension](https://github.com/Such-Software/smirk-extension) is frozen at v0.2.x; `packages/extension/` here is the canonical v0.3+ client.

## Layout

```
smirk-monorepo/
├── crates/                   # Rust workspace
│   ├── monero-oxide/         # vendored — Monero + Wownero transaction library
│   ├── secp256k1zkp/         # vendored — Grin's secp256k1-zkp Rust bindings
│   │                         #   (Bulletproofs, Pedersen, aggsig); patched for wasm32
│   ├── smirk-wasm/           # wasm-bindgen wrapper, single WASM bundle for JS consumers
│   ├── grin-ext/             # Grin / Mimblewimble protocol implementation
│   ├── btc-ext/              # BTC + LTC: BIP32, P2WPKH/P2TR addresses, PSBT signing
│   └── swap-core/            # atomic swap state machine (stub — v0.4)
├── packages/                 # npm workspace (TypeScript)
│   ├── wasm/                 # @smirk/wasm — TS bindings around crates/smirk-wasm/pkg/
│   ├── core/                 # @smirk/core — API client, crypto, HD derivation, codecs
│   ├── assets/               # @smirk/assets — pure-data registry of every supported chain
│   ├── ui/                   # @smirk/ui — shared Preact components (BalanceCard, ActionButton, ApprovalScreen, ...)
│   ├── dapp-api/             # @smirk/dapp-api — transport-agnostic window.smirk wire protocol + WalletHandler
│   └── extension/            # @smirk/extension — Chrome MV3 + Firefox
├── docs/                     # design notes per crate
├── Cargo.toml                # flat Rust workspace, all crates listed at root
├── package.json              # npm workspace root
├── tsconfig.base.json        # shared TS compiler config
├── Makefile                  # cross-language build orchestration
└── MONOREPO.md               # developer guide
```

## Build

Requires:
- A recent stable Rust toolchain with the `wasm32-unknown-unknown` target
- A `wasm-bindgen-cli` version matching `Cargo.lock`
- Node.js 20+

```bash
# Cargo workspace
make rust-build      # cargo build --release --workspace
make rust-test       # cargo test --workspace

# WASM bundle (output: crates/smirk-wasm/pkg/)
make wasm

# TypeScript workspace (depends on WASM)
make ts-install      # npm install across packages/*
make ts-typecheck    # tsc --noEmit across packages/*
make ts-build        # tsc -p across packages/*

# Everything (Rust + WASM + TS)
make build
make test
```

CI runs the same `make` targets — see [.github/workflows/ci.yml](.github/workflows/ci.yml).

## Reproducible from source

For reviewers (Mozilla AMO, App Store, security audits) the goal is `git clone → make build → byte-equivalent output`. Every byte of crypto code lives in `crates/`. The standalone Rust crate `wownero-oxide` is published to crates.io for external consumers, but the monorepo build does not depend on the published version — `crates/monero-oxide/` is the source of truth.

## Companion repos

| Repo | Role |
|---|---|
| [Such-Software/smirk-extension](https://github.com/Such-Software/smirk-extension) | Legacy v0.2.x browser extension. Frozen — `packages/extension/` here is the canonical v0.3+ client. |
| [Such-Software/monero-oxide](https://github.com/Such-Software/monero-oxide) | Standalone fork retained for `wownero-*` crates.io publishing; kept in sync with this monorepo via `git subtree` |
| [monero-oxide/monero-oxide](https://github.com/monero-oxide/monero-oxide) | Upstream — Monero only |

## License

MIT — see [LICENSE](LICENSE).
